# youtube-downloader

This is a package that allows you to download videos and audios from youtube

**USAGE**
```python
from youtube_downloader import YouTubeDownloader
downloader = YouTubeDownloader()
downloader.download('youtube_video_url')
```